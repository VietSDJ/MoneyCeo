webpackHotUpdate_N_E("pages/index",{

/***/ "./assets/images/favicons/apple-touch-icon.png":
/*!*****************************************************!*\
  !*** ./assets/images/favicons/apple-touch-icon.png ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "/_next/static/images/apple-touch-icon-35a5efb29ca3f36b63fec699b7a6424c.png";

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vYXNzZXRzL2ltYWdlcy9mYXZpY29ucy9hcHBsZS10b3VjaC1pY29uLnBuZyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBQSw4RiIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9pbmRleC4wN2U3ZTBkOTU0NmNhZTMxODQyMy5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsibW9kdWxlLmV4cG9ydHMgPSBcIi9fbmV4dC9zdGF0aWMvaW1hZ2VzL2FwcGxlLXRvdWNoLWljb24tMzVhNWVmYjI5Y2EzZjM2YjYzZmVjNjk5YjdhNjQyNGMucG5nXCI7Il0sInNvdXJjZVJvb3QiOiIifQ==